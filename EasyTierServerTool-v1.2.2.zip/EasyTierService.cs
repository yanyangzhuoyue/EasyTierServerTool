using System;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;
using System.Threading;

namespace EasyTierServerTool
{
    /// <summary>
    /// Windows 服务宿主：本工具以 /service [服务名] 启动时作为服务运行，
    /// 负责拉起 easytier-core 子进程、记录日志、崩溃自动重启。
    /// </summary>
    public class EasyTierServerService : ServiceBase
    {
        private Process _proc;
        private System.Timers.Timer _watchdog;
        private string _baseDir;
        private Settings _settings;
        private string _logFile;
        private volatile bool _stopping = false;
        private readonly object _sync = new object();

        public EasyTierServerService(string serviceName)
        {
            ServiceName = string.IsNullOrEmpty(serviceName) ? "EasyTierServer" : serviceName;
            CanStop = true;
            CanShutdown = true;
            AutoLog = true;
        }

        protected override void OnStart(string[] args)
        {
            _baseDir = AppDomain.CurrentDomain.BaseDirectory;
            _settings = Settings.Load(_baseDir);
            _logFile = Path.Combine(Path.Combine(_baseDir, "logs"), "service.log");
            try { Directory.CreateDirectory(Path.Combine(_baseDir, "logs")); } catch { }
            Util.WriteLog(_logFile, "=== EasyTier 服务启动（服务名: " + ServiceName + "）===");
            StartCore();
            _watchdog = new System.Timers.Timer(5000);
            _watchdog.Elapsed += delegate { CheckCore(); };
            _watchdog.Start();
        }

        protected override void OnStop()
        {
            _stopping = true;
            if (_watchdog != null) { _watchdog.Stop(); _watchdog.Dispose(); _watchdog = null; }
            StopCore();
            Util.WriteLog(_logFile, "=== EasyTier 服务停止 ===");
        }

        protected override void OnShutdown()
        {
            OnStop();
        }

        private void StartCore()
        {
            lock (_sync)
            {
                if (_proc != null && !_proc.HasExited) return;
                if (_settings == null || string.IsNullOrEmpty(_settings.CorePath) || !File.Exists(_settings.CorePath))
                {
                    Util.WriteLog(_logFile, "错误: easytier-core.exe 不存在或未配置: " + (_settings == null ? "(无配置)" : _settings.CorePath));
                    return;
                }
                try
                {
                    string[] args = CoreArgs.Build(_settings, _baseDir);
                    ProcessStartInfo psi = new ProcessStartInfo(_settings.CorePath, ArgLine.Join(args));
                    psi.UseShellExecute = false;
                    psi.RedirectStandardOutput = true;
                    psi.RedirectStandardError = true;
                    psi.CreateNoWindow = true;
                    psi.WorkingDirectory = _baseDir;

                    _proc = Process.Start(psi);
                    _proc.OutputDataReceived += delegate(object s, DataReceivedEventArgs e)
                    {
                        if (e.Data != null) Util.WriteLog(_logFile, e.Data);
                    };
                    _proc.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e)
                    {
                        if (e.Data != null) Util.WriteLog(_logFile, "[stderr] " + e.Data);
                    };
                    _proc.BeginOutputReadLine();
                    _proc.BeginErrorReadLine();

                    Util.WriteLog(_logFile, "已启动 easytier-core，PID=" + _proc.Id);
                    Util.WriteLog(_logFile, "命令: " + _settings.CorePath + " " + ArgLine.Join(args));
                }
                catch (Exception ex)
                {
                    Util.WriteLog(_logFile, "启动 easytier-core 失败: " + ex.Message);
                    _proc = null;
                }
            }
        }

        private void CheckCore()
        {
            if (_stopping) return;
            lock (_sync)
            {
                if (_proc != null && _proc.HasExited)
                {
                    int code = _proc.ExitCode;
                    Util.WriteLog(_logFile, "easytier-core 异常退出（代码 " + code + "），5 秒后自动重启");
                    _proc = null;
                    ThreadPool.QueueUserWorkItem(delegate
                    {
                        Thread.Sleep(5000);
                        if (!_stopping) StartCore();
                    });
                }
            }
        }

        private void StopCore()
        {
            lock (_sync)
            {
                if (_proc != null)
                {
                    try { if (!_proc.HasExited) _proc.Kill(); } catch { }
                    try { _proc.WaitForExit(10000); } catch { }
                    _proc = null;
                }
            }
        }
    }
}
