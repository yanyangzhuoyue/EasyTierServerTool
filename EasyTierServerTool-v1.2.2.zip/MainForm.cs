﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace EasyTierServerTool
{
    /// <summary>主界面：图形化安装配置 EasyTier 服务器</summary>
    public class MainForm : Form
    {
        private readonly string _baseDir;
        private Settings _s;
        private Process _fgProc;                     // 前台试运行进程
        private string _fgLogFile;
        private string _activeLogFile;               // 当前日志查看文件
        private long _logReadPos;
        private string _lastCommand = "";

        private System.Windows.Forms.Timer _uiTimer;                      // 状态刷新
        private System.Windows.Forms.Timer _logTimer;                     // 日志尾部刷新
        private bool _statusBusy;                    // 状态检测进行中（防止重入）

        // —— 控件 ——
        private TextBox txtCore, txtServiceName, txtInstance, txtHost, txtNetName, txtSecret,
                        txtIpv4, txtKey, txtCmdPreview;
        private ComboBox cmbMirror;
        private CheckBox chkShowSecret, chkIpv6, chkTcp, chkUdp, chkWs, chkWg,
                          chkPrivate, chkSecure, chkMulti, chkAutoStart, chkRestart;
        private NumericUpDown numPort, numWgPort;
        private ComboBox cmbIpMode, cmbConsoleLog, cmbFileLog;
        private Button btnBrowse, btnDownload, btnImportZip, btnGenKey,
                       btnInstall, btnUninstall, btnStart, btnStop, btnRestart, btnRefresh,
                       btnForeground, btnStopFg, btnPreview, btnSave, btnExport, btnOpenLogDir, btnClearLog;
        private RichTextBox txtLog;
        private Label lblSvcInfo, lblLogFile;
        private ToolStripStatusLabel lblStatus, lblPort, lblVer, lblDl;
        private ToolStripProgressBar pbDl;
        private System.Windows.Forms.Timer _autoSaveTimer;

        public MainForm()
        {
            _baseDir = AppDomain.CurrentDomain.BaseDirectory;
            _s = Settings.Load(_baseDir);
            AutoDetectCore();
            _autoSaveTimer = new System.Windows.Forms.Timer(); _autoSaveTimer.Interval = 400; _autoSaveTimer.Tick += OnAutoSaveTick;
            // 双缓冲 + 平滑重绘（缓解拖动卡顿/闪烁）
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            AutoScaleMode = AutoScaleMode.None; // 布局缩放由 ApplyDpiScale 手动控制
            BuildUi();
            ApplySettingsToUi();
            // 配置变更即自动保存（防抖）：即使程序被强杀/崩溃/断电，已修改的配置也已落盘
            HookAutoSave(this);
            ApplyDpiScale();
            RefreshStatus();

            _uiTimer = new System.Windows.Forms.Timer(); _uiTimer.Interval = 2000; _uiTimer.Tick += delegate { RefreshStatus(); }; _uiTimer.Start();
            _logTimer = new System.Windows.Forms.Timer(); _logTimer.Interval = 2000; _logTimer.Tick += delegate { RefreshLog(); }; _logTimer.Start();
        }

        // ================= 高分屏 DPI 缩放 =================
        // 说明：控件字体按“点”为单位会自动随 DPI 放大，而控件坐标/尺寸是像素，
        // 需要按 dpi/96 比例手动放大，否则高分辨率下文字溢出、被截断、互相重叠。
        private void ApplyDpiScale()
        {
            float dpi = 96f;
            try { using (Graphics g = CreateGraphics()) dpi = g.DpiX; } catch { }
            // 测试钩子：ETS_FORCE_DPI=125 可强制按 125% 布局（仅用于界面自检）
            string env = Environment.GetEnvironmentVariable("ETS_FORCE_DPI");
            if (!string.IsNullOrEmpty(env))
            {
                float v;
                if (float.TryParse(env, out v) && v >= 96f) dpi = v;
            }
            float f = dpi / 96f;
            if (f <= 1.001f) return;
            if (!string.IsNullOrEmpty(env))
            {
                // 测试钩子模式下模拟真实 DPI 字体渲染（真实环境字体由系统自动放大，此处手动等效模拟）
                Font = new Font(Font.FontFamily, Font.Size * f);
                ScaleFontsRecursive(this, f);
            }
            ScaleControlRecursive(this, f);
            ClientSize = new Size((int)Math.Round(ClientSize.Width * f), (int)Math.Round(ClientSize.Height * f));
            MinimumSize = new Size((int)Math.Round(MinimumSize.Width * f), (int)Math.Round(MinimumSize.Height * f));
        }

        private static void ScaleFontsRecursive(Control c, float f)
        {
            c.Font = new Font(c.Font.FontFamily, c.Font.Size * f);
            foreach (Control child in c.Controls) ScaleFontsRecursive(child, f);
        }

        private static void ScaleControlRecursive(Control c, float f)
        {
            foreach (Control child in c.Controls)
            {
                if (child is StatusStrip) continue; // Dock 布局由系统管理
                ScaleControlRecursive(child, f);
                child.Location = new Point((int)Math.Round(child.Location.X * f), (int)Math.Round(child.Location.Y * f));
                // AutoSize 控件会按缩放后的字体自动计算尺寸，手动缩放尺寸会双倍放大
                if (!child.AutoSize) child.Size = new Size((int)Math.Round(child.Size.Width * f), (int)Math.Round(child.Size.Height * f));
            }
        }

        // ================= 界面构建 =================
        private void BuildUi()
        {
            Text = "EasyTier 服务器安装配置工具";
            ClientSize = new Size(960, 700);
            MinimumSize = new Size(940, 640);
            StartPosition = FormStartPosition.CenterScreen;
            try { Font = new Font("Microsoft YaHei", 9F); } catch { }

            TabControl tabs = new TabControl();
            tabs.Location = new Point(12, 8);
            tabs.Size = new Size(936, 640);
            Controls.Add(tabs);

            // ---------- Tab1 基本配置 ----------
            TabPage tab1 = new TabPage("① 基本配置");
            tabs.TabPages.Add(tab1);

            // ① 服务器程序
            GroupBox gCore = new GroupBox(); gCore.Text = "① 服务器程序 (easytier-core.exe)"; gCore.SetBounds(8, 6, 908, 62);
            tab1.Controls.Add(gCore);
            gCore.Controls.Add(MakeLabel("程序路径:", 12, 28));
            txtCore = MakeTextBox(88, 24, 560); gCore.Controls.Add(txtCore);
            btnBrowse = MakeButton("浏览...", 656, 23, 84); btnBrowse.Click += delegate { BrowseCore(); }; gCore.Controls.Add(btnBrowse);
            btnDownload = MakeButton("下载最新版", 748, 23, 104); btnDownload.Click += delegate { DownloadCore(); }; gCore.Controls.Add(btnDownload);
            gCore.Controls.Add(MakeLabel("提示：可点击“下载最新版”自动获取官方程序，或手动解压官方 zip 后选择 easytier-core.exe", 12, 49, 880, 16));

            // ② 网络设置
            GroupBox gNet = new GroupBox(); gNet.Text = "② 网络设置（客户端接入凭证）"; gNet.SetBounds(8, 74, 908, 118);
            tab1.Controls.Add(gNet);
            gNet.Controls.Add(MakeLabel("网络名称:", 12, 30));
            txtNetName = MakeTextBox(88, 26, 250); gNet.Controls.Add(txtNetName);
            gNet.Controls.Add(MakeLabel("网络密钥:", 366, 30));
            txtSecret = MakeTextBox(442, 26, 170); txtSecret.PasswordChar = '*'; gNet.Controls.Add(txtSecret);
            chkShowSecret = MakeCheck("显示", 618, 29); chkShowSecret.CheckedChanged += delegate { txtSecret.PasswordChar = chkShowSecret.Checked ? '\0' : '*'; }; gNet.Controls.Add(chkShowSecret);
            Button btnSecGen = MakeButton("随机生成", 672, 26, 84); btnSecGen.Click += delegate { txtSecret.Text = Util.RandomKey().Substring(0, 16); }; gNet.Controls.Add(btnSecGen);
            gNet.Controls.Add(MakeLabel("实例名称:", 12, 62));
            txtInstance = MakeTextBox(88, 58, 250); gNet.Controls.Add(txtInstance);
            gNet.Controls.Add(MakeLabel("主机名:", 366, 62));
            txtHost = MakeTextBox(442, 58, 200); gNet.Controls.Add(txtHost);
            gNet.Controls.Add(MakeLabel("客户端使用相同“网络名称 + 网络密钥”即可加入本服务器组网", 12, 92, 880, 16));

            // ③ 监听设置
            GroupBox gListen = new GroupBox(); gListen.Text = "③ 监听设置（客户端连接入口）"; gListen.SetBounds(8, 198, 908, 116);
            tab1.Controls.Add(gListen);
            gListen.Controls.Add(MakeLabel("监听端口:", 12, 30));
            numPort = MakeNumeric(88, 26, 11010, 1, 65535); gListen.Controls.Add(numPort);
            chkTcp = MakeCheck("TCP", 260, 29); chkTcp.Checked = true; gListen.Controls.Add(chkTcp);
            chkUdp = MakeCheck("UDP", 325, 29); chkUdp.Checked = true; gListen.Controls.Add(chkUdp);
            chkWs = MakeCheck("WebSocket", 390, 29); gListen.Controls.Add(chkWs);
            chkWg = MakeCheck("WireGuard", 510, 29); gListen.Controls.Add(chkWg);
            gListen.Controls.Add(MakeLabel("WG端口:", 622, 30));
            numWgPort = MakeNumeric(698, 26, 11011, 1, 65535); gListen.Controls.Add(numWgPort);
            gListen.Controls.Add(MakeLabel("建议勾选 TCP + UDP。若为公网服务器，请在防火墙 / 安全组放行所选端口", 12, 60, 880, 16));
            gListen.Controls.Add(MakeLabel("监听地址:", 12, 86));
            txtCmdPreview = MakeTextBox(88, 82, 800); txtCmdPreview.ReadOnly = true; gListen.Controls.Add(txtCmdPreview);
            EventHandler upd = delegate { UpdatePreview(); };
            chkTcp.CheckedChanged += upd;
            chkUdp.CheckedChanged += upd;
            chkWs.CheckedChanged += upd;
            chkWg.CheckedChanged += upd;
            numPort.ValueChanged += upd;
            numWgPort.ValueChanged += upd;
            // 注意：此处不再立即调用 UpdatePreview()——BuildUi 阶段控件还是默认值，
            // 此时 GatherFromUi 会把已 Load 的配置覆盖成默认（导致重开不加载配置）。
            // 预览在 ApplySettingsToUi() 末尾统一生成。

            // ④ 地址与安全
            GroupBox gAddr = new GroupBox(); gAddr.Text = "④ 地址与安全"; gAddr.SetBounds(8, 320, 908, 120);
            tab1.Controls.Add(gAddr);
            gAddr.Controls.Add(MakeLabel("本机IP:", 12, 30));
            cmbIpMode = MakeCombo(88, 26, 300);
            cmbIpMode.Items.AddRange(new object[] { "纯转发服务器（推荐，不建虚拟网卡）", "DHCP 自动分配 IP", "手动指定 IP" });
            cmbIpMode.SelectedIndex = 0; cmbIpMode.SelectedIndexChanged += delegate { UpdateIpControls(); }; gAddr.Controls.Add(cmbIpMode);
            txtIpv4 = MakeTextBox(412, 26, 120); gAddr.Controls.Add(txtIpv4);
            chkIpv6 = MakeCheck("启用 IPv6", 550, 29); chkIpv6.Checked = true; gAddr.Controls.Add(chkIpv6);
            chkMulti = MakeCheck("多线程运行（--multi-thread）", 660, 29); gAddr.Controls.Add(chkMulti);
            // 私有模式独占一行（固定宽度避免文字过长时挤压/重叠右侧控件）
            chkPrivate = MakeCheck("私有模式：仅允许使用相同网络名称和密钥的节点经本服务器中转（推荐）", 12, 58);
            chkPrivate.AutoSize = false; chkPrivate.Width = 880; chkPrivate.Checked = true; gAddr.Controls.Add(chkPrivate);
            chkSecure = MakeCheck("安全模式(Secure Mode)", 12, 88); chkSecure.CheckedChanged += delegate { UpdateSecureControls(); }; gAddr.Controls.Add(chkSecure);
            gAddr.Controls.Add(MakeLabel("固定私钥:", 216, 88));
            txtKey = MakeTextBox(295, 84, 300); txtKey.ReadOnly = true; gAddr.Controls.Add(txtKey);
            btnGenKey = MakeButton("生成随机私钥", 602, 83, 110); btnGenKey.Click += delegate { txtKey.Text = Util.RandomKey(); }; gAddr.Controls.Add(btnGenKey);
            UpdateIpControls(); UpdateSecureControls();

            // ⑤ 日志
            GroupBox gLog = new GroupBox(); gLog.Text = "⑤ 日志"; gLog.SetBounds(8, 446, 908, 92);
            tab1.Controls.Add(gLog);
            gLog.Controls.Add(MakeLabel("控制台日志级别:", 12, 30));
            cmbConsoleLog = MakeCombo(150, 26, 110);
            cmbConsoleLog.Items.AddRange(new object[] { "off", "error", "warn", "info", "debug", "trace" });
            cmbConsoleLog.SelectedIndex = 3; gLog.Controls.Add(cmbConsoleLog);
            gLog.Controls.Add(MakeLabel("文件日志级别:", 300, 30));
            cmbFileLog = MakeCombo(420, 26, 110);
            cmbFileLog.Items.AddRange(new object[] { "off", "error", "warn", "info", "debug", "trace" });
            cmbFileLog.SelectedIndex = 3; gLog.Controls.Add(cmbFileLog);
            gLog.Controls.Add(MakeLabel("文件日志写入 logs\\easytier.log（按天滚动自动清理）", 540, 30, 360, 16));
            // 镜像前缀：可下拉选择常用加速地址，也可手动输入自定义地址；完整说明放入悬停提示
            Label lblMirror = MakeLabel("下载镜像前缀(可选)", 12, 62);
            ToolTip tipMirror = new ToolTip();
            tipMirror.SetToolTip(lblMirror, "GitHub 下载慢时选一个加速前缀，或直接输入自定义地址；留空表示直连 GitHub");
            gLog.Controls.Add(lblMirror);
            cmbMirror = MakeCombo(160, 58, 500);
            cmbMirror.DropDownStyle = ComboBoxStyle.DropDown; // 可下拉选择，也可手动输入
            cmbMirror.Items.AddRange(new object[] {
                "https://ghfast.top/",
                "https://gh-proxy.com/",
                "https://mirror.ghproxy.com/",
                "https://ghproxy.net/",
                "https://gh.llkk.cc/",
                "https://github.moeyy.xyz/",
                "https://ghps.cc/",
                "https://gh.ddlc.top/",
                "https://hub.gitmirror.com/"
            });
            tipMirror.SetToolTip(cmbMirror, "GitHub 下载慢时选一个加速前缀，或直接输入自定义地址；留空表示直连 GitHub");
            gLog.Controls.Add(cmbMirror);

            // ---------- Tab2 服务与运行 ----------
            TabPage tab2 = new TabPage("② 服务与运行");
            tabs.TabPages.Add(tab2);

            GroupBox gSvc = new GroupBox(); gSvc.Text = "⑥ Windows 服务（后台运行、开机自启）"; gSvc.SetBounds(8, 6, 908, 168);
            tab2.Controls.Add(gSvc);
            gSvc.Controls.Add(MakeLabel("服务名:", 12, 30));
            txtServiceName = MakeTextBox(88, 26, 200); gSvc.Controls.Add(txtServiceName);
            gSvc.Controls.Add(MakeLabel("服务将本工具注册为系统服务，自动拉起 easytier-core；安装需管理员权限", 320, 28, 600, 16));
            chkAutoStart = MakeCheck("开机自动启动", 12, 58); chkAutoStart.Checked = true; gSvc.Controls.Add(chkAutoStart);
            chkRestart = MakeCheck("进程崩溃自动重启（5秒后拉起）", 150, 58); chkRestart.Checked = true; gSvc.Controls.Add(chkRestart);
            btnInstall = MakeButton("① 安装服务", 12, 88, 100); btnInstall.Click += delegate { InstallService(); }; gSvc.Controls.Add(btnInstall);
            btnStart = MakeButton("② 启动服务", 120, 88, 100); btnStart.Click += delegate { ServiceAction("start"); }; gSvc.Controls.Add(btnStart);
            btnStop = MakeButton("③ 停止服务", 228, 88, 100); btnStop.Click += delegate { ServiceAction("stop"); }; gSvc.Controls.Add(btnStop);
            btnRestart = MakeButton("④ 重启服务", 336, 88, 100); btnRestart.Click += delegate { ServiceAction("restart"); }; gSvc.Controls.Add(btnRestart);
            btnUninstall = MakeButton("⑤ 卸载服务", 444, 88, 100); btnUninstall.Click += delegate { UninstallService(); }; gSvc.Controls.Add(btnUninstall);
            btnRefresh = MakeButton("刷新状态", 552, 88, 100); btnRefresh.Click += delegate { RefreshStatus(); }; gSvc.Controls.Add(btnRefresh);
            lblSvcInfo = MakeLabel("", 12, 124, 880, 34); lblSvcInfo.ForeColor = Color.FromArgb(30, 90, 160); gSvc.Controls.Add(lblSvcInfo);

            GroupBox gRun = new GroupBox(); gRun.Text = "⑦ 运行与配置"; gRun.SetBounds(8, 180, 908, 150);
            tab2.Controls.Add(gRun);
            btnForeground = MakeButton("前台试运行（调试）", 12, 30, 140); btnForeground.Click += delegate { RunForeground(); }; gRun.Controls.Add(btnForeground);
            btnStopFg = MakeButton("停止运行", 160, 30, 100); btnStopFg.Click += delegate { StopForeground(); }; gRun.Controls.Add(btnStopFg);
            btnPreview = MakeButton("生成启动命令预览", 268, 30, 150); btnPreview.Click += delegate { BuildPreview(true); }; gRun.Controls.Add(btnPreview);
            btnSave = MakeButton("保存配置", 426, 30, 100); btnSave.Click += delegate { SaveSettings(true); }; gRun.Controls.Add(btnSave);
            btnExport = MakeButton("导出TOML配置", 534, 30, 132); btnExport.Click += delegate { ExportToml(); }; gRun.Controls.Add(btnExport);
            btnImportZip = MakeButton("导入本地安装包", 674, 30, 130); btnImportZip.Click += delegate { ImportZip(); }; gRun.Controls.Add(btnImportZip);
            btnOpenLogDir = MakeButton("打开日志目录", 12, 64, 110); btnOpenLogDir.Click += delegate { OpenLogDir(); }; gRun.Controls.Add(btnOpenLogDir);
            gRun.Controls.Add(MakeLabel("最近生成的启动命令:", 12, 98, 160, 16));
            TextBox txtFull = new TextBox();
            txtFull.SetBounds(12, 116, 880, 22); txtFull.ReadOnly = true;
            txtFull.Text = "(点击“生成启动命令预览”查看)"; txtFull.Name = "txtFullCmd";
            gRun.Controls.Add(txtFull);

            GroupBox gHelp = new GroupBox(); gHelp.Text = "⑧ 客户端如何连接本服务器"; gHelp.SetBounds(8, 336, 908, 185);
            tab2.Controls.Add(gHelp);
            TextBox txtHelp = new TextBox(); txtHelp.Multiline = true; txtHelp.ReadOnly = true; txtHelp.WordWrap = false;
            txtHelp.SetBounds(12, 24, 884, 152); txtHelp.BorderStyle = BorderStyle.None; txtHelp.BackColor = SystemColors.Control;
            txtHelp.Text =
"在其他电脑上解压 EasyTier 官方包，管理员运行：\r\n" +
"  easytier-core.exe -d --network-name 网络名称 --network-secret 网络密钥 -p tcp://本服务器公网IP:监听端口\r\n" +
"例如（端口 11010、名称 easytier-net）：\r\n" +
"  easytier-core.exe -d --network-name easytier-net --network-secret 你的密钥 -p tcp://1.2.3.4:11010\r\n" +
"提示：-d 表示客户端自动获取虚拟 IP；若已指定私有模式，客户端必须使用完全相同的网络名称与密钥。";
            gHelp.Controls.Add(txtHelp);

            // ---------- Tab3 日志 ----------
            TabPage tab3 = new TabPage("③ 日志");
            tabs.TabPages.Add(tab3);
            Panel pLogTop = new Panel(); pLogTop.Dock = DockStyle.Top; pLogTop.Height = 34; tab3.Controls.Add(pLogTop);
            lblLogFile = MakeLabel("日志文件: (无)", 12, 12, 640, 16); pLogTop.Controls.Add(lblLogFile);
            btnClearLog = MakeButton("清空显示", 700, 8, 90); btnClearLog.Click += delegate { txtLog.Clear(); }; pLogTop.Controls.Add(btnClearLog);
            Button btnOpen2 = MakeButton("打开日志目录", 798, 8, 110); btnOpen2.Click += delegate { OpenLogDir(); }; pLogTop.Controls.Add(btnOpen2);
            txtLog = new RichTextBox(); txtLog.Dock = DockStyle.Fill; txtLog.ReadOnly = true; txtLog.BackColor = Color.White;
            txtLog.Font = new Font("Consolas", 9F);
            txtLog.DetectUrls = false;   // 减少绘制开销（日志内容无需识别超链接）
            txtLog.WordWrap = false;     // 关闭自动换行，大幅降低大文本重排开销，拖动更流畅
            tab3.Controls.Add(txtLog);

            // ---------- 状态栏 ----------
            StatusStrip ss = new StatusStrip();
            lblStatus = new ToolStripStatusLabel("服务: -"); lblPort = new ToolStripStatusLabel("端口: -"); lblVer = new ToolStripStatusLabel("v1.2.2 · 兼容 Win7/Server2008R2+");
            lblDl = new ToolStripStatusLabel(""); pbDl = new ToolStripProgressBar(); pbDl.Width = 120; pbDl.Visible = false;
            ss.Items.Add(lblStatus); ss.Items.Add(lblPort); ss.Items.Add(new ToolStripStatusLabel("  ")); ss.Items.Add(pbDl); ss.Items.Add(lblDl); ss.Items.Add(new ToolStripStatusLabel("  ")); ss.Items.Add(lblVer);
            Controls.Add(ss);

            FormClosing += delegate { SaveSettings(false); StopForeground(); };
        }

        /// <summary>给所有输入控件挂上“变更→自动保存”事件（防抖 400ms）</summary>
        private void HookAutoSave(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c is TextBox)
                {
                    TextBox tb = (TextBox)c;
                    if (!tb.ReadOnly) tb.TextChanged += OnUiChanged;
                }
                else if (c is CheckBox) ((CheckBox)c).CheckedChanged += OnUiChanged;
                else if (c is NumericUpDown) ((NumericUpDown)c).ValueChanged += OnUiChanged;
                else if (c is ComboBox)
                {
                    ComboBox cb = (ComboBox)c;
                    cb.TextChanged += OnUiChanged;
                    cb.SelectedIndexChanged += OnUiChanged;
                }
                if (c.Controls.Count > 0) HookAutoSave(c);
            }
        }
        private void OnUiChanged(object sender, EventArgs e)
        {
            _autoSaveTimer.Stop();
            _autoSaveTimer.Start();
        }
        private void OnAutoSaveTick(object sender, EventArgs e)
        {
            _autoSaveTimer.Stop();
            try { GatherFromUi(); _s.Save(_baseDir); } catch { }
        }

        // ================= 小控件工厂 =================
        private static Label MakeLabel(string t, int x, int y) { return MakeLabel(t, x, y, 0, 16); }
        private static Label MakeLabel(string t, int x, int y, int w, int h)
        {
            Label l = new Label(); l.Text = t; l.Location = new Point(x, y);
            l.AutoSize = w <= 0; if (w > 0) { l.Width = w; l.Height = h; l.AutoEllipsis = true; }
            return l;
        }
        private static TextBox MakeTextBox(int x, int y, int w)
        {
            TextBox t = new TextBox(); t.Location = new Point(x, y); t.Width = w; return t;
        }
        private static CheckBox MakeCheck(string t, int x, int y)
        {
            CheckBox c = new CheckBox(); c.Text = t; c.Location = new Point(x, y); c.AutoSize = true; return c;
        }
        private static Button MakeButton(string t, int x, int y, int w)
        {
            Button b = new Button(); b.Text = t; b.Location = new Point(x, y); b.Width = w; return b;
        }
        private static NumericUpDown MakeNumeric(int x, int y, int val, int min, int max)
        {
            NumericUpDown n = new NumericUpDown(); n.Location = new Point(x, y); n.Width = 90;
            n.Minimum = min; n.Maximum = max; n.Value = val; return n;
        }
        private static ComboBox MakeCombo(int x, int y, int w)
        {
            ComboBox c = new ComboBox(); c.Location = new Point(x, y); c.Width = w; c.DropDownStyle = ComboBoxStyle.DropDownList; return c;
        }

        // ================= 配置读写 =================
        private void AutoDetectCore()
        {
            if (!string.IsNullOrEmpty(_s.CorePath) && File.Exists(_s.CorePath)) return;
            string[] cands = new string[] {
                Path.Combine(_baseDir, "easytier-core.exe"),
                Path.Combine(Path.Combine(_baseDir, "easytier"), "easytier-core.exe"),
                Path.Combine(Path.Combine(_baseDir, ".."), "easytier-core.exe")
            };
            foreach (string c in cands)
            {
                if (File.Exists(c)) { _s.CorePath = Path.GetFullPath(c); return; }
            }
        }

        private bool _applyingUi; // 防止 ApplySettingsToUi 过程中控件事件把 _s 覆盖成控件默认值

        private void ApplySettingsToUi()
        {
            _applyingUi = true;
            try
            {
                txtCore.Text = _s.CorePath;
                txtServiceName.Text = _s.ServiceName;
                txtInstance.Text = _s.InstanceName;
                txtHost.Text = _s.HostName;
                txtNetName.Text = _s.NetworkName;
                txtSecret.Text = _s.NetworkSecret;
                numPort.Value = Clamp(_s.ListenPort, 1, 65535, 11010);
                numWgPort.Value = Clamp(_s.WgPort, 1, 65535, 11011);
                chkTcp.Checked = _s.ListenTcp;
                chkUdp.Checked = _s.ListenUdp;
                chkWs.Checked = _s.ListenWs;
                chkWg.Checked = _s.ListenWg;
                cmbIpMode.SelectedIndex = _s.IpMode >= 0 && _s.IpMode <= 2 ? _s.IpMode : 0;
                txtIpv4.Text = _s.Ipv4Address;
                chkIpv6.Checked = _s.EnableIpv6;
                chkPrivate.Checked = _s.PrivateMode;
                chkSecure.Checked = _s.SecureMode;
                txtKey.Text = _s.LocalPrivateKey;
                chkMulti.Checked = _s.MultiThread;
                SetCombo(cmbConsoleLog, _s.ConsoleLogLevel, 3);
                SetCombo(cmbFileLog, _s.FileLogLevel, 3);
                cmbMirror.Text = _s.Mirror;
                chkAutoStart.Checked = _s.AutoStart;
                chkRestart.Checked = _s.RestartOnCrash;
                UpdateIpControls(); UpdateSecureControls();
            }
            finally { _applyingUi = false; }
            UpdatePreview();
        }

        private void GatherFromUi()
        {
            if (txtCore != null) _s.CorePath = txtCore.Text.Trim();
            if (txtServiceName != null) _s.ServiceName = string.IsNullOrEmpty(txtServiceName.Text.Trim()) ? "EasyTierServer" : txtServiceName.Text.Trim();
            if (txtInstance != null) _s.InstanceName = txtInstance.Text.Trim();
            if (txtHost != null) _s.HostName = txtHost.Text.Trim();
            if (txtNetName != null) _s.NetworkName = txtNetName.Text.Trim();
            if (txtSecret != null) _s.NetworkSecret = txtSecret.Text;
            if (numPort != null) _s.ListenPort = (int)numPort.Value;
            if (numWgPort != null) _s.WgPort = (int)numWgPort.Value;
            if (chkTcp != null) _s.ListenTcp = chkTcp.Checked;
            if (chkUdp != null) _s.ListenUdp = chkUdp.Checked;
            if (chkWs != null) _s.ListenWs = chkWs.Checked;
            if (chkWg != null) _s.ListenWg = chkWg.Checked;
            if (cmbIpMode != null) _s.IpMode = cmbIpMode.SelectedIndex < 0 ? 0 : cmbIpMode.SelectedIndex;
            if (txtIpv4 != null) _s.Ipv4Address = txtIpv4.Text.Trim();
            if (chkIpv6 != null) _s.EnableIpv6 = chkIpv6.Checked;
            if (chkPrivate != null) _s.PrivateMode = chkPrivate.Checked;
            if (chkSecure != null) _s.SecureMode = chkSecure.Checked;
            if (txtKey != null) _s.LocalPrivateKey = txtKey.Text.Trim();
            if (chkMulti != null) _s.MultiThread = chkMulti.Checked;
            if (cmbConsoleLog != null) _s.ConsoleLogLevel = cmbConsoleLog.SelectedItem == null ? "info" : cmbConsoleLog.SelectedItem.ToString();
            if (cmbFileLog != null) _s.FileLogLevel = cmbFileLog.SelectedItem == null ? "info" : cmbFileLog.SelectedItem.ToString();
            if (cmbMirror != null) _s.Mirror = cmbMirror.Text.Trim();
            if (chkAutoStart != null) _s.AutoStart = chkAutoStart.Checked;
            if (chkRestart != null) _s.RestartOnCrash = chkRestart.Checked;
        }

        private void SaveSettings(bool showMsg)
        {
            GatherFromUi();
            _s.Save(_baseDir);
            if (showMsg) MessageBox.Show("配置已保存到 " + Path.Combine(_baseDir, "easytier-server-settings.xml"), "保存成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private static int Clamp(int v, int lo, int hi, int def) { if (v < lo || v > hi) return def; return v; }
        private static void SetCombo(ComboBox c, string val, int defIdx)
        {
            int i = c.Items.IndexOf(val);
            c.SelectedIndex = i >= 0 ? i : defIdx;
        }

        private void UpdateIpControls()
        {
            bool manual = cmbIpMode != null && cmbIpMode.SelectedIndex == 2;
            if (txtIpv4 != null) txtIpv4.Enabled = manual;
        }
        private void UpdateSecureControls()
        {
            bool on = chkSecure != null && chkSecure.Checked;
            if (txtKey != null) { txtKey.Enabled = on; }
            if (btnGenKey != null) btnGenKey.Enabled = on;
        }
        private void UpdatePreview()
        {
            if (_applyingUi) return; // ApplySettingsToUi 赋值触发的中间事件不重算，末尾统一生成
            if (txtCmdPreview == null) return;
            GatherFromUi();
            string[] args = CoreArgs.Build(_s, _baseDir);
            txtCmdPreview.Text = ArgLine.Join(args);
        }
        private void BuildPreview(bool showMsg)
        {
            GatherFromUi();
            string[] args = CoreArgs.Build(_s, _baseDir);
            _lastCommand = _s.CorePath + " " + ArgLine.Join(args);
            SetFullCmd(_lastCommand);
            if (showMsg)
            {
                string msg = "easytier-core.exe 启动命令：\r\n\r\n" + _lastCommand + "\r\n\r\n" +
                             (File.Exists(_s.CorePath) ? "" : "注意：easytier-core.exe 不存在！请先选择/下载程序。");
                MessageBox.Show(msg, "启动命令预览", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void SetFullCmd(string cmd)
        {
            // 查找 Tab2 上的完整命令文本框
            foreach (Control c in Controls)
            {
                TabControl tabs = c as TabControl;
                if (tabs == null) continue;
                foreach (TabPage tp in tabs.TabPages)
                {
                    FindAndSet(tp, "txtFullCmd", cmd);
                }
            }
        }
        private static void FindAndSet(Control root, string name, string val)
        {
            foreach (Control c in root.Controls)
            {
                if (c.Name == name && c is TextBox) { ((TextBox)c).Text = val; return; }
                if (c.HasChildren) FindAndSet(c, name, val);
            }
        }

        // ================= 服务器程序 =================
        private void BrowseCore()
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Title = "选择 easytier-core.exe";
            d.Filter = "easytier-core.exe|easytier-core.exe|所有文件|*.*";
            d.InitialDirectory = string.IsNullOrEmpty(_s.CorePath) ? _baseDir : Path.GetDirectoryName(_s.CorePath);
            if (d.ShowDialog(this) == DialogResult.OK) txtCore.Text = d.FileName;
        }

        private void DownloadCore()
        {
            string ver = PickVersion(_s.LastVersion);
            if (ver == null) return;
            ver = ver.Trim();
            if (ver.Length == 0 || ver == "最新稳定版（自动检测）")
            {
                string latest = Util.GetLatestVersion();
                ver = string.IsNullOrEmpty(latest) ? "v2.6.4" : latest;
            }
            if (ver[0] != 'v') ver = "v" + ver;
            _s.LastVersion = ver;
            string arch = IntPtr.Size == 8 ? "x86_64" : "i686";
            string fileName = "easytier-windows-" + arch + "-" + ver + ".zip";
            string url = "https://github.com/EasyTier/EasyTier/releases/download/" + ver + "/" + fileName;
            string mirror = cmbMirror.Text.Trim();
            if (mirror.Length > 0) url = mirror.TrimEnd('/') + "/" + url;
            string dlDir = Path.Combine(_baseDir, "downloads");
            try { Directory.CreateDirectory(dlDir); } catch { }
            string zipPath = Path.Combine(dlDir, fileName);
            string extractDir = Path.Combine(_baseDir, "easytier");

            SetDl(true, "准备下载 " + fileName + " ...");
            ThreadPool.QueueUserWorkItem(delegate
            {
                bool ok = Util.DownloadFile(url, zipPath, delegate(int p) { SetDlProgress(p); },
                    delegate(string st) { SetDlText(st); });
                if (!ok) { SetDl(false, "下载失败，可改用手动下载后点击“导入本地安装包”"); return; }
                SetDlText("下载完成，正在解压...");
                bool ex = Util.ExtractZip(zipPath, extractDir);
                if (!ex) { SetDl(false, "解压失败，请手动解压官方 zip 后选择 easytier-core.exe"); return; }
                string core = Path.Combine(extractDir, "easytier-core.exe");
                if (!File.Exists(core))
                {
                    // 可能解压出子目录，递归查找
                    string[] found = Directory.GetFiles(extractDir, "easytier-core.exe", SearchOption.AllDirectories);
                    if (found.Length > 0) core = found[0];
                }
                if (File.Exists(core))
                {
                    SetUiText(txtCore, core);
                    SetDl(false, "安装完成：" + core);
                }
                else SetDl(false, "未在压缩包中找到 easytier-core.exe");
            });
        }

        private void ImportZip()
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Title = "选择 EasyTier 官方 Windows 压缩包";
            d.Filter = "zip 压缩包|*.zip|所有文件|*.*";
            if (d.ShowDialog(this) != DialogResult.OK) return;
            string extractDir = Path.Combine(_baseDir, "easytier");
            SetDl(true, "正在解压 " + Path.GetFileName(d.FileName) + " ...");
            ThreadPool.QueueUserWorkItem(delegate
            {
                bool ex = Util.ExtractZip(d.FileName, extractDir);
                if (!ex) { SetDl(false, "解压失败"); return; }
                string core = Path.Combine(extractDir, "easytier-core.exe");
                if (!File.Exists(core))
                {
                    string[] found = Directory.GetFiles(extractDir, "easytier-core.exe", SearchOption.AllDirectories);
                    if (found.Length > 0) core = found[0];
                }
                if (File.Exists(core))
                {
                    SetUiText(txtCore, core);
                    SetDl(false, "导入完成：" + core);
                }
                else SetDl(false, "未在压缩包中找到 easytier-core.exe");
            });
        }

        // ================= 前台试运行 =================
        private void RunForeground()
        {
            GatherFromUi();
            if (!File.Exists(_s.CorePath)) { MessageBox.Show("请先选择 easytier-core.exe 程序路径", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (Util.PortListening(_s.ListenPort)) { MessageBox.Show("端口 " + _s.ListenPort + " 已被占用（可能服务已在运行），请先停止服务再试运行", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            try { Directory.CreateDirectory(Path.Combine(_baseDir, "logs")); } catch { }
            _fgLogFile = Path.Combine(Path.Combine(_baseDir, "logs"), "foreground.log");
            string[] args = CoreArgs.Build(_s, _baseDir);
            Util.WriteLog(_fgLogFile, "=== 前台试运行开始 ===");
            Util.WriteLog(_fgLogFile, "命令: " + _s.CorePath + " " + ArgLine.Join(args));
            ProcessStartInfo psi = new ProcessStartInfo(_s.CorePath, ArgLine.Join(args));
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;
            psi.WorkingDirectory = _baseDir;
            try
            {
                _fgProc = Process.Start(psi);
                _fgProc.OutputDataReceived += delegate(object s, DataReceivedEventArgs e)
                {
                    if (e.Data != null) { Util.WriteLog(_fgLogFile, e.Data); AppendLogText(e.Data + "\r\n"); }
                };
                _fgProc.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e)
                {
                    if (e.Data != null) { Util.WriteLog(_fgLogFile, "[stderr] " + e.Data); AppendLogText("[stderr] " + e.Data + "\r\n"); }
                };
                _fgProc.BeginOutputReadLine();
                _fgProc.BeginErrorReadLine();
                SetUiText(txtLog, "已启动 easytier-core，PID=" + _fgProc.Id + "\r\n");
            }
            catch (Exception ex) { MessageBox.Show("启动失败：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error); _fgProc = null; }
            RefreshStatus();
        }

        private void StopForeground()
        {
            if (_fgProc != null)
            {
                try { if (!_fgProc.HasExited) _fgProc.Kill(); } catch { }
                try { _fgProc.WaitForExit(5000); } catch { }
                if (_fgLogFile != null) Util.WriteLog(_fgLogFile, "=== 前台试运行已停止 ===");
                _fgProc = null;
            }
        }

        // ================= 服务管理 =================
        private void InstallService()
        {
            GatherFromUi();
            if (!File.Exists(_s.CorePath)) { MessageBox.Show("请先选择 easytier-core.exe 程序路径", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (ServiceManager.Exists(_s.ServiceName))
            {
                MessageBox.Show("服务 " + _s.ServiceName + " 已存在，请先卸载或使用其他服务名", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string exe = Path.Combine(_baseDir, "EasyTierServerTool.exe");
            if (!File.Exists(exe)) exe = Application.ExecutablePath;
            string disp = "EasyTier Server (" + _s.NetworkName + ")";
            SaveSettings(false);
            string result = ServiceManager.Install(_s.ServiceName, exe, disp, _s.AutoStart, _s.RestartOnCrash);
            MessageBox.Show(result, "安装结果", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshStatus();
        }

        private void UninstallService()
        {
            if (!ServiceManager.Exists(_s.ServiceName)) { MessageBox.Show("服务未安装", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            string result = ServiceManager.Uninstall(_s.ServiceName);
            MessageBox.Show(result, "卸载结果", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshStatus();
        }

        private void ServiceAction(string act)
        {
            try
            {
                if (act == "start") ServiceManager.Start(_s.ServiceName);
                else if (act == "stop") ServiceManager.Stop(_s.ServiceName);
                else if (act == "restart") ServiceManager.Restart(_s.ServiceName);
                MessageBox.Show("操作成功", "服务管理", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("操作失败：" + ex.Message, "服务管理", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            RefreshStatus();
        }

        /// <summary>
        /// 刷新状态（异步）：服务查询与端口探测在线程池执行，避免阻塞 UI 线程导致拖动卡顿。
        /// </summary>
        private void RefreshStatus()
        {
            if (_statusBusy) return;
            string svc = _s.ServiceName;
            int port = _s.ListenPort;
            _statusBusy = true;
            ThreadPool.QueueUserWorkItem(delegate
            {
                string st = "NotInstalled";
                bool listening = false;
                try { st = ServiceManager.GetState(svc); } catch { }
                try { listening = Util.PortListening(port); } catch { }
                if (IsDisposed) { _statusBusy = false; return; }
                try
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        if (IsDisposed) return;
                        ApplyStatus(st, listening);
                        _statusBusy = false;
                    });
                }
                catch { _statusBusy = false; }
            });
        }

        private void ApplyStatus(string st, bool listening)
        {
            string cn = st == "Running" ? "运行中" : st == "Stopped" ? "已停止" : st == "StartPending" ? "启动中" : st == "StopPending" ? "停止中" : st == "NotInstalled" ? "未安装" : st;
            lblStatus.Text = "服务[" + _s.ServiceName + "]: " + cn;
            lblPort.Text = "端口 " + _s.ListenPort + (listening ? " ✓ 监听中" : " ✗ 未监听");
            bool fg = _fgProc != null && !_fgProc.HasExited;
            btnForeground.Enabled = !fg && st != "Running";
            btnStopFg.Enabled = fg;
            bool installed = st != "NotInstalled";
            btnInstall.Enabled = !installed;
            btnUninstall.Enabled = installed;
            btnStart.Enabled = installed && st != "Running";
            btnStop.Enabled = installed && st == "Running";
            btnRestart.Enabled = installed;
            string info = "服务状态: " + cn;
            if (installed)
            {
                info += "    |    启动方式: " + (_s.AutoStart ? "自动" : "手动") + "    崩溃自启: " + (_s.RestartOnCrash ? "开启" : "关闭");
            }
            if (fg) info += "    |    前台进程运行中";
            lblSvcInfo.Text = info;
        }

        // ================= 日志 =================
        private void RefreshLog()
        {
            string f = PickLogFile();
            if (f == null)
            {
                if (_activeLogFile != null) { _activeLogFile = null; }
                if (txtLog.Text.Length == 0) { SetUiText(lblLogFile, "日志文件: (无日志，请先试运行或安装服务)"); }
                return;
            }
            if (f != _activeLogFile)
            {
                _activeLogFile = f;
                _logReadPos = 0;
                AppendLogText("\r\n==== 切换到日志: " + Path.GetFileName(f) + " ====\r\n");
                SetUiText(lblLogFile, "日志文件: " + f);
            }
            try
            {
                long len = new FileInfo(f).Length;
                if (len < _logReadPos) _logReadPos = 0;
                long start = _logReadPos;
                if (start == 0 && len > 40000) start = len - 40000; // 首次显示末尾40KB
                if (len > start)
                {
                    using (FileStream fs = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        fs.Seek(start, SeekOrigin.Begin);
                        byte[] buf = new byte[len - start];
                        int n = fs.Read(buf, 0, buf.Length);
                        _logReadPos = start + n;
                        if (n > 0) AppendLogText(Encoding.UTF8.GetString(buf, 0, n));
                    }
                }
            }
            catch { }
        }

        private string PickLogFile()
        {
            string logsDir = Path.Combine(_baseDir, "logs");
            if (!Directory.Exists(logsDir)) return null;
            if (_fgProc != null && !_fgProc.HasExited && _fgLogFile != null && File.Exists(_fgLogFile)) return _fgLogFile;
            string svcLog = Path.Combine(logsDir, "service.log");
            string etLog = Path.Combine(logsDir, "easytier.log");
            if (File.Exists(etLog)) return etLog;
            if (File.Exists(svcLog)) return svcLog;
            return null;
        }

        private void AppendLogText(string s)
        {
            if (txtLog == null) return;
            if (txtLog.InvokeRequired) { txtLog.BeginInvoke((MethodInvoker)delegate { AppendLogText(s); }); return; }
            txtLog.AppendText(s);
            if (txtLog.TextLength > 150000) txtLog.Text = txtLog.Text.Substring(txtLog.TextLength - 100000);
        }

        // ================= 其它 =================
        private void ExportToml()
        {
            GatherFromUi();
            SaveFileDialog d = new SaveFileDialog();
            d.Title = "导出 EasyTier 参考配置文件";
            d.Filter = "TOML 文件|*.toml|所有文件|*.*";
            d.FileName = "easytier-server.toml";
            if (d.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                File.WriteAllText(d.FileName, CoreArgs.BuildToml(_s), Encoding.UTF8);
                MessageBox.Show("已导出: " + d.FileName + "\r\n\r\n可使用: easytier-core.exe -c \"" + d.FileName + "\" 加载（实际服务以界面参数为准）", "导出完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("导出失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void OpenLogDir()
        {
            string dir = Path.Combine(_baseDir, "logs");
            try { Directory.CreateDirectory(dir); } catch { }
            try { Process.Start("explorer.exe", "\"" + dir + "\""); }
            catch (Exception ex) { MessageBox.Show("打开失败: " + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        // ================= UI线程辅助 =================
        private void SetUiText(Control c, string text)
        {
            if (c == null) return;
            if (c.InvokeRequired) { c.BeginInvoke((MethodInvoker)delegate { c.Text = text; }); return; }
            c.Text = text;
        }
        private void SetDl(bool visible, string text)
        {
            if (pbDl == null) return;
            if (InvokeRequired) { if (IsDisposed) return; BeginInvoke((MethodInvoker)delegate { SetDl(visible, text); }); return; }
            pbDl.Visible = visible;
            lblDl.Text = text;
            if (!visible) pbDl.Value = 0;
        }
        private void SetDlProgress(int p)
        {
            if (pbDl == null) return;
            if (InvokeRequired) { if (IsDisposed) return; BeginInvoke((MethodInvoker)delegate { SetDlProgress(p); }); return; }
            pbDl.Value = p;
            lblDl.Text = "下载中 " + p + "%";
        }
        private void SetDlText(string text)
        {
            if (lblDl == null) return;
            if (InvokeRequired) { if (IsDisposed) return; BeginInvoke((MethodInvoker)delegate { lblDl.Text = text; }); return; }
            lblDl.Text = text;
        }

        /// <summary>版本选择对话框：可下拉选择常用稳定版本，也可手动输入任意版本；留空表示自动检测最新</summary>
        private static string PickVersion(string current)
        {
            Form f = new Form();
            f.Text = "下载 EasyTier 官方程序";
            f.Width = 500; f.Height = 180;
            f.StartPosition = FormStartPosition.CenterParent;
            f.FormBorderStyle = FormBorderStyle.FixedDialog;
            f.MaximizeBox = false; f.MinimizeBox = false;
            Label l = new Label();
            l.Text = "选择常用稳定版本，或手动输入任意版本号（留空则自动检测最新稳定版）";
            l.SetBounds(12, 12, f.ClientSize.Width - 24, 30); f.Controls.Add(l);
            ComboBox c = new ComboBox();
            c.DropDownStyle = ComboBoxStyle.DropDown; // 可下拉选择，也可手动输入
            c.SetBounds(12, 44, f.ClientSize.Width - 24, 24);
            c.Items.Add("最新稳定版（自动检测）");
            c.Items.Add("v2.6.4"); c.Items.Add("v2.6.3"); c.Items.Add("v2.6.2"); c.Items.Add("v2.6.1"); c.Items.Add("v2.6.0");
            c.Items.Add("v2.5.0"); c.Items.Add("v2.4.5"); c.Items.Add("v2.4.4"); c.Items.Add("v2.4.3"); c.Items.Add("v2.4.2"); c.Items.Add("v2.4.1"); c.Items.Add("v2.4.0");
            if (!string.IsNullOrEmpty(current) && c.Items.Contains(current)) c.SelectedItem = current;
            else c.Text = current;
            f.Controls.Add(c);
            Button ok = new Button(); ok.Text = "下载"; ok.DialogResult = DialogResult.OK; ok.SetBounds(f.ClientSize.Width - 200, 84, 90, 30); f.Controls.Add(ok);
            Button cancel = new Button(); cancel.Text = "取消"; cancel.DialogResult = DialogResult.Cancel; cancel.SetBounds(f.ClientSize.Width - 102, 84, 90, 30); f.Controls.Add(cancel);
            f.AcceptButton = ok; f.CancelButton = cancel;
            return f.ShowDialog() == DialogResult.OK ? c.Text.Trim() : null;
        }
    }
}
