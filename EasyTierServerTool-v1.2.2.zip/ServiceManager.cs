using System;
using System.Diagnostics;
using System.ServiceProcess;

namespace EasyTierServerTool
{
    /// <summary>Windows 服务管理（安装/卸载/启停/状态）</summary>
    public static class ServiceManager
    {
        public static bool Exists(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            try
            {
                using (ServiceController sc = new ServiceController(name))
                {
                    ServiceControllerStatus st = sc.Status; // 抛出异常即不存在
                    return true;
                }
            }
            catch { return false; }
        }

        /// <summary>返回服务状态英文枚举（未安装返回 "NotInstalled"）</summary>
        public static string GetState(string name)
        {
            if (string.IsNullOrEmpty(name) || !Exists(name)) return "NotInstalled";
            try
            {
                using (ServiceController sc = new ServiceController(name))
                {
                    return sc.Status.ToString();
                }
            }
            catch { return "Unknown"; }
        }

        /// <summary>安装服务。exePath 为本工具自身路径（本工具同时充当服务宿主）</summary>
        public static string Install(string name, string exePath, string displayName, bool autoStart, bool restartOnCrash)
        {
            // sc 语法要求 binPath 值内层再引号：binPath= "\"C:\path\tool.exe\" /service NAME"
            string binPathValue = "\"" + exePath + "\" /service " + name;
            string startType = autoStart ? "auto" : "demand";
            string args = "create " + name + " binPath= \"" + binPathValue.Replace("\"", "\\\"") + "\""
                        + " start= " + startType
                        + " DisplayName= \"" + displayName + "\"";
            string out1 = Util.RunSc(args);
            string out2 = "";
            if (restartOnCrash)
            {
                out2 = Util.RunSc("failure " + name + " reset= 86400 actions= restart/5000/restart/15000/restart/60000");
            }
            return out1 + "\r\n\r\n" + out2;
        }

        public static string Uninstall(string name)
        {
            string out1 = Util.RunSc("stop " + name);   // 未运行/不存在会报错，忽略
            string out2 = Util.RunSc("delete " + name);
            return out1 + "\r\n\r\n" + out2;
        }

        public static void Start(string name)
        {
            using (ServiceController sc = new ServiceController(name))
            {
                if (sc.Status != ServiceControllerStatus.Running)
                {
                    sc.Start();
                    sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
                }
            }
        }

        public static void Stop(string name)
        {
            using (ServiceController sc = new ServiceController(name))
            {
                if (sc.Status != ServiceControllerStatus.Stopped)
                {
                    sc.Stop();
                    sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
                }
            }
        }

        public static void Restart(string name)
        {
            using (ServiceController sc = new ServiceController(name))
            {
                if (sc.Status == ServiceControllerStatus.Running)
                {
                    sc.Stop();
                    sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
                }
                sc.Start();
                sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
            }
        }
    }
}
