@echo off
rem ============================================================
rem  EasyTierServerTool build script
rem  Target: .NET Framework 3.5 (Windows Server 2008 R2 compatible)
rem  Usage : double-click build.bat or run from cmd
rem ============================================================
setlocal
cd /d "%~dp0"

set CSC=
if exist "%WINDIR%\Microsoft.NET\Framework\v3.5\csc.exe" set CSC=%WINDIR%\Microsoft.NET\Framework\v3.5\csc.exe
if not defined CSC if exist "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not defined CSC (
  echo [ERROR] C# compiler not found. Install .NET Framework 3.5 or 4.x first.
  exit /b 1
)
echo [1/3] Compiler: %CSC%

echo [2/3] Generating icon.ico ...
"%CSC%" /nologo /target:exe /optimize+ /out:IconGen.exe /r:System.dll /r:System.Drawing.dll IconGen.cs >nul 2>&1
if exist IconGen.exe (
  IconGen.exe
  del IconGen.exe
) else (
  echo       Icon generation skipped.
)

echo [3/3] Compiling EasyTierServerTool.exe ...
"%CSC%" /nologo /target:winexe /optimize+ /win32manifest:app.manifest /win32icon:icon.ico /out:EasyTierServerTool.exe ^
  /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Xml.dll /r:System.ServiceProcess.dll ^
  Program.cs Settings.cs CoreArgs.cs Util.cs ServiceManager.cs EasyTierService.cs MainForm.cs

if errorlevel 1 (
  echo [ERROR] Compile failed. See messages above.
  exit /b 1
)

echo.
echo [DONE] EasyTierServerTool.exe generated.
echo        Output dir: %CD%
if exist "%WINDIR%\Microsoft.NET\Framework\v3.5\csc.exe" (
  echo        Framework: .NET 3.5, runs directly on Server 2008 R2
) else (
  echo        NOTE: compiled with .NET 4.x, Server 2008 R2 needs .NET Framework 4.x
)
exit /b 0
