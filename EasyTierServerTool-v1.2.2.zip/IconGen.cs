using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

/// <summary>生成程序图标 icon.ico（多尺寸 PNG 压缩 ICO，兼容 Vista+）</summary>
class IconGen
{
    static GraphicsPath RoundRect(RectangleF r, float rad)
    {
        GraphicsPath p = new GraphicsPath();
        float d = rad * 2f;
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    static Bitmap Draw(int size)
    {
        Bitmap bmp = new Bitmap(size, size, PixelFormat.Format32bppArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float s = size;
            float m = s * 0.04f;
            RectangleF r = new RectangleF(m, m, s - 2 * m, s - 2 * m);
            using (GraphicsPath gp = RoundRect(r, s * 0.18f))
            using (LinearGradientBrush br = new LinearGradientBrush(r, Color.FromArgb(30, 58, 138), Color.FromArgb(37, 99, 235), 45f))
            {
                g.FillPath(br, gp);
            }
            // 网络节点连线
            PointF[] nodes = { new PointF(s * 0.30f, s * 0.32f), new PointF(s * 0.70f, s * 0.32f), new PointF(s * 0.50f, s * 0.70f) };
            using (Pen pen = new Pen(Color.White, Math.Max(1f, s * 0.045f)))
            {
                pen.StartCap = LineCap.Round; pen.EndCap = LineCap.Round;
                g.DrawLine(pen, nodes[0], nodes[1]);
                g.DrawLine(pen, nodes[0], nodes[2]);
                g.DrawLine(pen, nodes[1], nodes[2]);
            }
            float nr = s * 0.085f;
            using (SolidBrush br = new SolidBrush(Color.White))
            {
                foreach (PointF p in nodes) g.FillEllipse(br, p.X - nr, p.Y - nr, nr * 2, nr * 2);
            }
            float cr = s * 0.05f;
            using (SolidBrush br = new SolidBrush(Color.FromArgb(147, 197, 253)))
            {
                g.FillEllipse(br, s * 0.5f - cr, s * 0.5f - cr, cr * 2, cr * 2);
            }
        }
        return bmp;
    }

    static int Main(string[] args)
    {
        int[] sizes = { 16, 24, 32, 48, 64, 128, 256 };
        using (MemoryStream ms = new MemoryStream())
        {
            BinaryWriter w = new BinaryWriter(ms);
            w.Write((short)0); w.Write((short)1); w.Write((short)sizes.Length);
            int offset = 6 + 16 * sizes.Length;
            byte[][] datas = new byte[sizes.Length][];
            for (int i = 0; i < sizes.Length; i++)
            {
                using (Bitmap b = Draw(sizes[i]))
                using (MemoryStream png = new MemoryStream())
                {
                    b.Save(png, ImageFormat.Png);
                    datas[i] = png.ToArray();
                }
                int wh = sizes[i] >= 256 ? 0 : sizes[i];
                w.Write((byte)wh); w.Write((byte)wh);
                w.Write((byte)0); w.Write((byte)0);
                w.Write((short)1); w.Write((short)32);
                w.Write(datas[i].Length); w.Write(offset);
                offset += datas[i].Length;
            }
            foreach (byte[] d in datas) w.Write(d);
            File.WriteAllBytes("icon.ico", ms.ToArray());
        }
        using (Icon ic = new Icon("icon.ico"))
        {
            Console.WriteLine("icon.ico 生成成功: " + ic.Width + "x" + ic.Height);
        }
        return 0;
    }
}
