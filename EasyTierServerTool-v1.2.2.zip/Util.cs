using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace EasyTierServerTool
{
    /// <summary>通用工具：sc 调用、端口探测、日志、解压、下载等</summary>
    public static class Util
    {
        /// <summary>执行 sc.exe 并返回输出（用于 create/delete/failure）</summary>
        public static string RunSc(string args)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("sc.exe", args);
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                psi.CreateNoWindow = true;
                using (Process p = Process.Start(psi))
                {
                    string so = p.StandardOutput.ReadToEnd();
                    string se = p.StandardError.ReadToEnd();
                    p.WaitForExit();
                    return (so + "\r\n" + se).Trim();
                }
            }
            catch (Exception ex) { return "调用 sc.exe 失败: " + ex.Message; }
        }

        /// <summary>探测本地 TCP 端口是否在监听</summary>
        public static bool PortListening(int port)
        {
            if (port < 1 || port > 65535) return false;
            try
            {
                using (TcpClient c = new TcpClient())
                {
                    IAsyncResult r = c.BeginConnect("127.0.0.1", port, null, null);
                    bool ok = r.AsyncWaitHandle.WaitOne(1500, false);
                    if (ok) { c.EndConnect(r); c.Close(); return true; }
                }
            }
            catch { }
            return false;
        }

        /// <summary>写一行日志到文件（UTF-8）</summary>
        public static void WriteLog(string file, string msg)
        {
            try
            {
                string dir = Path.GetDirectoryName(file);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
                using (FileStream fs = new FileStream(file, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                {
                    byte[] b = Encoding.UTF8.GetBytes(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + msg + "\r\n");
                    fs.Write(b, 0, b.Length);
                }
            }
            catch { }
        }

        /// <summary>使用 Shell.Application COM 解压 zip（兼容 XP~Server 2008 R2，无需额外组件）</summary>
        public static bool ExtractZip(string zipPath, string destDir)
        {
            try
            {
                if (!Directory.Exists(destDir)) Directory.CreateDirectory(destDir);
                Type shellType = Type.GetTypeFromProgID("Shell.Application");
                if (shellType == null) return false;
                object shell = Activator.CreateInstance(shellType);
                object src = shellType.InvokeMember("NameSpace", BindingFlags.InvokeMethod, null, shell, new object[] { zipPath });
                if (src == null) return false;
                object dst = shellType.InvokeMember("NameSpace", BindingFlags.InvokeMethod, null, shell, new object[] { destDir });
                object items = src.GetType().InvokeMember("Items", BindingFlags.InvokeMethod, null, src, null);
                dst.GetType().InvokeMember("CopyHere", BindingFlags.InvokeMethod, null, dst, new object[] { items, 0x14 });
                // CopyHere 异步执行，轮询等待文件出现（最长60秒）
                int waited = 0;
                while (waited < 60)
                {
                    string[] files = Directory.GetFiles(destDir);
                    if (files.Length > 0) return true;
                    Thread.Sleep(1000); waited++;
                }
                return Directory.GetFiles(destDir).Length > 0;
            }
            catch { return false; }
        }

        /// <summary>下载文件（自动启用 TLS1.0~1.2；2008 R2 使用 TLS1.2 需安装 KB3140245）</summary>
        public static bool DownloadFile(string url, string destPath, Action<int> progress, Action<string> status)
        {
            try
            {
                try
                {
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)(48 | 192 | 768 | 3072); // SSL3|TLS1.0|TLS1.1|TLS1.2
                }
                catch { }
                if (status != null) status("开始下载: " + url);
                using (WebClient wc = new WebClient())
                {
                    wc.Headers.Add("User-Agent", "Mozilla/5.0 EasyTierServerTool");
                    AutoResetEvent done = new AutoResetEvent(false);
                    Exception err = null;
                    wc.DownloadFileCompleted += delegate(object s, System.ComponentModel.AsyncCompletedEventArgs e)
                    {
                        err = e.Error;
                        done.Set();
                    };
                    if (progress != null) wc.DownloadProgressChanged += delegate(object s, DownloadProgressChangedEventArgs e)
                    {
                        progress(e.ProgressPercentage);
                    };
                    wc.DownloadFileAsync(new Uri(url), destPath);
                    done.WaitOne();
                    if (err != null) throw err;
                }
                if (progress != null) progress(100);
                return File.Exists(destPath) && new FileInfo(destPath).Length > 0;
            }
            catch (Exception ex)
            {
                if (status != null) status("下载失败: " + ex.Message);
                return false;
            }
        }

        /// <summary>查询 GitHub 上 EasyTier 的最新发布版本号（如 v2.6.4），失败返回 null</summary>
        public static string GetLatestVersion()
        {
            try
            {
                try
                {
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)(48 | 192 | 768 | 3072); // SSL3|TLS1.0|TLS1.1|TLS1.2
                }
                catch { }
                using (WebClient wc = new WebClient())
                {
                    wc.Headers.Add("User-Agent", "Mozilla/5.0 EasyTierServerTool");
                    string json = wc.DownloadString("https://api.github.com/repos/EasyTier/EasyTier/releases/latest");
                    System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(json, "\"tag_name\"\\s*:\\s*\"([^\"]+)\"");
                    if (m.Success) return m.Groups[1].Value;
                }
            }
            catch { }
            return null;
        }

        /// <summary>获取文件扩展短路径（减少命令行长度）</summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int GetShortPathName(string lpszLongPath, StringBuilder lpszShortPath, int cchBuffer);

        public static string ShortPath(string longPath)
        {
            try
            {
                StringBuilder sb = new StringBuilder(1024);
                int n = GetShortPathName(longPath, sb, sb.Capacity);
                if (n > 0 && n < sb.Capacity) return sb.ToString();
            }
            catch { }
            return longPath;
        }

        /// <summary>随机生成 base64 私钥（32字节）</summary>
        public static string RandomKey()
        {
            byte[] buf = new byte[32];
            System.Security.Cryptography.RNGCryptoServiceProvider rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
            rng.GetBytes(buf);
            return Convert.ToBase64String(buf);
        }
    }
}
