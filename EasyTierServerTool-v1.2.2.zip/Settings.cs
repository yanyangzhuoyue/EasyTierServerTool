using System;
using System.IO;
using System.Xml.Serialization;

namespace EasyTierServerTool
{
    /// <summary>
    /// 工具自身配置（保存于工具目录下的 easytier-server-settings.xml）
    /// </summary>
    [Serializable]
    public class Settings
    {
        // ① 服务器程序
        public string CorePath = "";                 // easytier-core.exe 完整路径

        // ② 网络设置
        public string NetworkName = "easytier-net";  // 网络名称（客户端凭此加入）
        public string NetworkSecret = "";            // 网络密钥
        public string InstanceName = "";             // 实例名（-m），默认机器名
        public string HostName = "";                 // 主机名（--hostname）

        // ③ 监听设置
        public int ListenPort = 11010;               // 监听端口
        public bool ListenTcp = true;                // TCP 监听
        public bool ListenUdp = true;                // UDP 监听
        public bool ListenWs = false;                // WebSocket 监听
        public bool ListenWg = false;                // WireGuard 监听
        public int WgPort = 11011;                   // WireGuard 端口

        // ④ 地址与安全
        public int IpMode = 0;                       // 0=纯转发(无虚拟网卡,推荐) 1=DHCP自动分配 2=手动指定IP
        public string Ipv4Address = "10.144.144.1";  // 手动指定IP
        public bool EnableIpv6 = true;               // 是否启用IPv6
        public bool PrivateMode = true;              // 私有模式：仅允许同网络节点中转
        public bool SecureMode = false;              // 安全模式(Secure Mode / Noise)
        public string LocalPrivateKey = "";          // Secure Mode 固定私钥(base64)

        // ⑤ 日志与性能
        public string ConsoleLogLevel = "info";      // 控制台日志级别
        public string FileLogLevel = "info";         // 文件日志级别（off=关闭文件日志）
        public bool MultiThread = false;             // 多线程运行

        // ⑥ 服务
        public string ServiceName = "EasyTierServer";// Windows 服务名
        public bool AutoStart = true;                // 开机自启
        public bool RestartOnCrash = true;           // 崩溃自动重启

        // 下载
        public string Mirror = "";                   // 下载镜像前缀，如 https://ghfast.top/
        public string LastVersion = "v2.6.4";        // 上次使用的版本号

        private static string FilePath(string dir)
        {
            return Path.Combine(dir, "easytier-server-settings.xml");
        }

        public static Settings Load(string dir)
        {
            Settings s = new Settings();
            s.InstanceName = Environment.MachineName;
            s.HostName = Environment.MachineName;
            string path = FilePath(dir);
            if (File.Exists(path))
            {
                try
                {
                    XmlSerializer xs = new XmlSerializer(typeof(Settings));
                    using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
                    {
                        s = (Settings)xs.Deserialize(fs);
                    }
                    if (string.IsNullOrEmpty(s.InstanceName)) s.InstanceName = Environment.MachineName;
                    if (string.IsNullOrEmpty(s.HostName)) s.HostName = Environment.MachineName;
                }
                catch (Exception ex)
                {
                    // 配置损坏：备份原文件（不覆盖用户数据）并记录日志，下次可诊断
                    try
                    {
                        File.Copy(path, path + ".bad-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"), true);
                        File.AppendAllText(Path.Combine(Path.GetDirectoryName(path), "settings-error.log"),
                            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 加载配置失败，原文件已备份为 .bad-*: " + ex.Message + "\r\n");
                    }
                    catch { }
                }
            }
            return s;
        }

        public void Save(string dir)
        {
            try
            {
                XmlSerializer xs = new XmlSerializer(typeof(Settings));
                using (FileStream fs = new FileStream(FilePath(dir), FileMode.Create, FileAccess.Write))
                {
                    xs.Serialize(fs, this);
                }
            }
            catch (Exception ex)
            {
                // 保存失败不再静默：记录日志便于诊断
                try
                {
                    File.AppendAllText(Path.Combine(dir, "settings-error.log"),
                        DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " 保存配置失败: " + ex.Message + "\r\n");
                }
                catch { }
            }
        }
    }
}
