using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace EasyTierServerTool
{
    /// <summary>命令行参数拼接工具</summary>
    public static class ArgLine
    {
        /// <summary>将参数数组拼接为命令行字符串（含空格/空值自动加引号）</summary>
        public static string Join(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string a in args)
            {
                if (sb.Length > 0) sb.Append(' ');
                if (a == null || a.Length == 0 || a.IndexOf(' ') >= 0)
                {
                    sb.Append('"').Append((a == null ? "" : a).Replace("\"", "\\\"")).Append('"');
                }
                else sb.Append(a);
            }
            return sb.ToString();
        }
    }

    /// <summary>
    /// 根据界面配置生成 easytier-core 启动参数。
    /// 依据官方文档 v2.x（easytier.cn/guide/network/configurations.html）：
    ///   -l, --listeners  监听器（tcp://0.0.0.0:11010 / udp://... / ws://... / wg:11011）
    ///   -m, --instance-name  实例名
    ///   -i, --ipv4       本节点IPv4（留空=纯转发服务器，不创建TUN）
    ///   -d, --dhcp       DHCP自动分配IP
    ///   --private-mode   不允许不同网络名称/密钥的节点经本节点中转
    ///   --secure-mode    启用Noise安全握手；共享节点建议固定 --local-private-key
    /// </summary>
    public static class CoreArgs
    {
        public static string[] Build(Settings s, string baseDir)
        {
            List<string> a = new List<string>();

            if (!string.IsNullOrEmpty(s.NetworkName)) { a.Add("--network-name"); a.Add(s.NetworkName.Trim()); }
            if (!string.IsNullOrEmpty(s.NetworkSecret)) { a.Add("--network-secret"); a.Add(s.NetworkSecret.Trim()); }
            if (!string.IsNullOrEmpty(s.InstanceName)) { a.Add("-m"); a.Add(s.InstanceName.Trim()); }
            if (!string.IsNullOrEmpty(s.HostName)) { a.Add("--hostname"); a.Add(s.HostName.Trim()); }

            // 监听器：默认全部绑定 0.0.0.0
            int port = s.ListenPort; if (port < 1 || port > 65535) port = 11010;
            List<string> ls = new List<string>();
            if (s.ListenTcp) ls.Add("tcp://0.0.0.0:" + port);
            if (s.ListenUdp) ls.Add("udp://0.0.0.0:" + port);
            if (s.ListenWs) ls.Add("ws://0.0.0.0:" + port);
            if (s.ListenWg)
            {
                int wg = s.WgPort; if (wg < 1 || wg > 65535) wg = 11011;
                ls.Add("wg:" + wg);
            }
            if (ls.Count == 0) ls.Add("tcp://0.0.0.0:" + port); // 至少保留TCP
            foreach (string l in ls) { a.Add("-l"); a.Add(l); }

            // IP 模式
            if (s.IpMode == 1) a.Add("-d");                                  // DHCP
            else if (s.IpMode == 2)                                          // 手动指定
            {
                string ip = s.Ipv4Address == null ? "" : s.Ipv4Address.Trim();
                if (ip.Length > 0) { a.Add("-i"); a.Add(ip); }
            }
            // IpMode==0 纯转发：不传 -i/-d，即不创建 TUN，仅做数据转发

            // 注意：v2.6+ 中 --private-mode 必须显式传 true/false；其它布尔参数带值也不影响旧版本
            if (!s.EnableIpv6) { a.Add("--disable-ipv6"); a.Add("true"); }
            a.Add("--private-mode"); a.Add(s.PrivateMode ? "true" : "false");
            if (s.SecureMode)
            {
                a.Add("--secure-mode"); a.Add("true");
                if (!string.IsNullOrEmpty(s.LocalPrivateKey)) { a.Add("--local-private-key"); a.Add(s.LocalPrivateKey.Trim()); }
            }
            if (s.MultiThread) { a.Add("--multi-thread"); a.Add("true"); }

            // 日志
            string cl = string.IsNullOrEmpty(s.ConsoleLogLevel) ? "info" : s.ConsoleLogLevel.Trim();
            a.Add("--console-log-level"); a.Add(cl);
            if (!string.IsNullOrEmpty(s.FileLogLevel) && s.FileLogLevel.Trim() != "off")
            {
                a.Add("--file-log-level"); a.Add(s.FileLogLevel.Trim());
                a.Add("--file-log-dir"); a.Add(Path.Combine(baseDir, "logs"));
                a.Add("--file-log-size"); a.Add("100");
                a.Add("--file-log-count"); a.Add("10");
            }

            return a.ToArray();
        }

        /// <summary>生成 easytier 参考配置文件（TOML），供 -c 加载；结构以 v2.6 实际导出的配置为准</summary>
        public static string BuildToml(Settings s)
        {
            StringBuilder b = new StringBuilder();
            b.AppendLine("# EasyTier 服务器配置文件（由 EasyTierServerTool 生成）");
            b.AppendLine("# 使用方式: easytier-core -c 本文件");
            b.AppendLine("# 说明: 本文件与界面生成的命令行参数等效；界面安装服务时使用命令行参数启动");
            b.AppendLine();

            if (!string.IsNullOrEmpty(s.InstanceName)) b.AppendLine("instance_name = \"" + Escape(s.InstanceName.Trim()) + "\"");
            if (!string.IsNullOrEmpty(s.HostName)) b.AppendLine("hostname = \"" + Escape(s.HostName.Trim()) + "\"");
            if (s.IpMode == 1) b.AppendLine("dhcp = true");
            else if (s.IpMode == 2) b.AppendLine("ipv4 = \"" + Escape(s.Ipv4Address.Trim()) + "\"");
            // IpMode==0 纯转发：不输出 ipv4/dhcp，节点仅转发数据包

            int port = s.ListenPort; if (port < 1 || port > 65535) port = 11010;
            List<string> ls = new List<string>();
            if (s.ListenTcp) ls.Add("tcp://0.0.0.0:" + port);
            if (s.ListenUdp) ls.Add("udp://0.0.0.0:" + port);
            if (s.ListenWs) ls.Add("ws://0.0.0.0:" + port);
            if (s.ListenWg)
            {
                int wg = s.WgPort; if (wg < 1 || wg > 65535) wg = 11011;
                ls.Add("wg:" + wg);
            }
            if (ls.Count == 0) ls.Add("tcp://0.0.0.0:" + port);
            b.AppendLine("listeners = [");
            foreach (string l in ls) b.AppendLine("    \"" + l + "\",");
            b.AppendLine("]");
            b.AppendLine("tcp_whitelist = []");
            b.AppendLine("udp_whitelist = []");
            b.AppendLine();

            b.AppendLine("[network_identity]");
            b.AppendLine("network_name = \"" + Escape(string.IsNullOrEmpty(s.NetworkName) ? "default" : s.NetworkName.Trim()) + "\"");
            b.AppendLine("network_secret = \"" + Escape(s.NetworkSecret == null ? "" : s.NetworkSecret.Trim()) + "\"");
            b.AppendLine();

            if (s.SecureMode)
            {
                b.AppendLine("[secure_mode]");
                b.AppendLine("enabled = true");
                if (!string.IsNullOrEmpty(s.LocalPrivateKey)) b.AppendLine("local_private_key = \"" + Escape(s.LocalPrivateKey.Trim()) + "\"");
                b.AppendLine();
            }

            b.AppendLine("[flags]");
            b.AppendLine("enable_ipv6 = " + (s.EnableIpv6 ? "true" : "false"));
            b.AppendLine("private_mode = " + (s.PrivateMode ? "true" : "false"));
            if (s.MultiThread) b.AppendLine("multi_thread = true");
            b.AppendLine();

            b.AppendLine("# 日志为进程级参数，请通过命令行设置: --console-log-level / --file-log-level / --file-log-dir");
            return b.ToString();
        }

        private static string Escape(string v)
        {
            return v.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
    }
}
