﻿using System;
using System.IO;
using System.ServiceProcess;
using System.Text;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("EasyTierServerTool")]
[assembly: System.Reflection.AssemblyDescription("EasyTier 服务器安装配置工具（图形界面，兼容 Windows Server 2008 R2）")]
[assembly: System.Reflection.AssemblyProduct("EasyTierServerTool")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Reflection.AssemblyVersion("1.2.2.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.2.2.0")]

namespace EasyTierServerTool
{
    internal static class Program
    {
        /// <summary>
        /// 入口。
        ///   正常启动      → 图形界面
        ///   /service [名] → 作为 Windows 服务运行（由 sc create 注册）
        ///   /selftest     → 自检（打印配置与命令，供部署前验证）
        ///   /? /-h        → 用法说明
        /// </summary>
        [STAThread]
        private static int Main(string[] args)
        {
            if (args != null && args.Length > 0)
            {
                string a = args[0].ToLowerInvariant();
                if (a == "/service" || a == "-service")
                {
                    string svcName = args.Length > 1 ? args[1] : "EasyTierServer";
                    ServiceBase.Run(new EasyTierServerService(svcName));
                    return 0;
                }
                if (a == "/selftest" || a == "-selftest")
                {
                    return RunSelfTest();
                }
                if (a == "/genconfig" || a == "-genconfig")
                {
                    string dir = AppDomain.CurrentDomain.BaseDirectory;
                    Settings s = Settings.Load(dir);
                    string outPath;
                    if (args.Length > 1 && args[1].Length > 0)
                    {
                        outPath = Path.IsPathRooted(args[1]) ? args[1] : Path.Combine(dir, args[1]);
                    }
                    else outPath = Path.Combine(dir, "easytier-server.toml");
                    try
                    {
                        File.WriteAllText(outPath, CoreArgs.BuildToml(s), Encoding.UTF8);
                        Console.WriteLine("已生成配置文件: " + outPath);
                        return 0;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("生成失败: " + ex.Message);
                        return 1;
                    }
                }
                if (a == "/uipreview" || a == "-uipreview")
                {
                    string dir = AppDomain.CurrentDomain.BaseDirectory;
                    string outPng = (args.Length > 1 && args[1].Length > 0)
                        ? (Path.IsPathRooted(args[1]) ? args[1] : Path.Combine(dir, args[1]))
                        : Path.Combine(dir, "uipreview.png");
                    return RunUiPreview(outPng);
                }
                if (a == "/?" || a == "-?" || a == "/h" || a == "-h" || a == "--help")
                {
                    Console.WriteLine("EasyTierServerTool - EasyTier 服务器安装配置工具");
                    Console.WriteLine("用法:");
                    Console.WriteLine("  EasyTierServerTool.exe               启动图形界面");
                    Console.WriteLine("  EasyTierServerTool.exe /service [名] 作为 Windows 服务运行(内部使用)");
                    Console.WriteLine("  EasyTierServerTool.exe /selftest      自检并打印启动命令");
                    return 0;
                }
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            string crashLog = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash.log");
            Application.ThreadException += delegate(object sender, System.Threading.ThreadExceptionEventArgs e)
            {
                try { File.WriteAllText(crashLog, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " ThreadException: " + e.Exception + "\r\n" + e.Exception.StackTrace); } catch { }
            };
            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                try { File.WriteAllText(crashLog, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Unhandled: " + e.ExceptionObject + "\r\n" + ((Exception)e.ExceptionObject).StackTrace); } catch { }
            };
            try
            {
                Application.Run(new MainForm());
            }
            catch (Exception ex)
            {
                try { File.WriteAllText(crashLog, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Main: " + ex + "\r\n" + ex.StackTrace); } catch { }
            }
            return 0;
        }

        private static int RunSelfTest()
        {
            AttachConsole(-1); // 附着父控制台，输出自检信息（无控制台时静默）
            string dir = AppDomain.CurrentDomain.BaseDirectory;
            Settings s = Settings.Load(dir);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("== EasyTierServerTool 自检 ==");
            sb.AppendLine("工具目录: " + dir);
            sb.AppendLine("服务名:   " + s.ServiceName);
            sb.AppendLine("core路径: " + s.CorePath + "  (存在: " + File.Exists(s.CorePath) + ")");
            sb.AppendLine("监听端口: " + s.ListenPort);
            sb.AppendLine();
            string[] args = CoreArgs.Build(s, dir);
            sb.AppendLine("启动参数:");
            sb.AppendLine("  " + ArgLine.Join(args));
            sb.AppendLine();
            sb.AppendLine("sc 安装命令（模板）:");
            sb.AppendLine("  sc create " + s.ServiceName + " binPath= \"\\\"" + Path.Combine(dir, "EasyTierServerTool.exe") + "\\\" /service " + s.ServiceName + "\" start= auto");
            sb.AppendLine();
            sb.AppendLine("日志目录: " + Path.Combine(dir, "logs"));
            sb.AppendLine("配置存在: " + File.Exists(Path.Combine(dir, "easytier-server-settings.xml")));
            Console.WriteLine(sb.ToString());
            try { File.WriteAllText(Path.Combine(dir, "selftest.txt"), sb.ToString(), Encoding.UTF8); } catch { }
            FreeConsole();
            return File.Exists(s.CorePath) ? 0 : 2;
        }

        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        private static extern bool AttachConsole(int pid);

        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        private static extern bool FreeConsole();

        /// <summary>界面渲染自检：将主窗体各标签页绘制为 PNG（仅用于构建期验证界面布局）</summary>
        private static int RunUiPreview(string outPngBase)
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                using (MainForm f = new MainForm())
                {
                    f.Show();
                    Application.DoEvents();
                    // 逐个标签页渲染
                    foreach (Control c in f.Controls)
                    {
                        TabControl tabs = c as TabControl;
                        if (tabs == null) continue;
                        for (int i = 0; i < tabs.TabPages.Count; i++)
                        {
                            tabs.SelectedIndex = i;
                            Application.DoEvents();
                            string png = (i == 0) ? outPngBase : outPngBase.Replace(".png", (i + 1) + ".png");
                            using (System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(f.Width, f.Height))
                            {
                                f.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, f.Width, f.Height));
                                bmp.Save(png, System.Drawing.Imaging.ImageFormat.Png);
                            }
                        }
                    }
                    f.Hide();
                }
                return 0;
            }
            catch (Exception ex)
            {
                try { File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash.log"), ex + "\r\n" + ex.StackTrace); } catch { }
                return 1;
            }
        }
    }
}
